package com.directchat.clicktomessage.unsaved

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
