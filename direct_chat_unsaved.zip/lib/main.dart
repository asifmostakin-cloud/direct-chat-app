import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl_phone_field/intl_phone_field.dart';
import 'package:url_launcher/url_launcher.dart';

void main() {
  runApp(const DirectChatApp());
}

class DirectChatApp extends StatelessWidget {
  const DirectChatApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Direct Chat',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.teal),
        useMaterial3: true,
      ),
      home: const DirectChatHomePage(),
    );
  }
}

class DirectChatHomePage extends StatefulWidget {
  const DirectChatHomePage({super.key});

  @override
  State<DirectChatHomePage> createState() => _DirectChatHomePageState();
}

class _DirectChatHomePageState extends State<DirectChatHomePage> {
  String _completePhoneNumber = '';
  bool _isValidNumber = false;
  
  // Platform selection: 0 = WhatsApp, 1 = WA Business, 2 = Telegram
  int _selectedPlatformIndex = 0;

  Future<void> _openChat() async {
    if (!_isValidNumber || _completePhoneNumber.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please enter a valid phone number')),
      );
      return;
    }

    // Telegram এর জন্য '+' সহ নম্বর প্রয়োজন হতে পারে
    final numberForTelegram = _completePhoneNumber.replaceAll(RegExp(r'[^\d+]'), '');
    // WhatsApp এর জন্য লিংকে '+' চিহ্ন থাকা যাবে না, শুধুমাত্র সংখ্যা হবে 
    final numberForWhatsApp = _completePhoneNumber.replaceAll(RegExp(r'[^\d]'), '');
    
    String urlString = '';
    
    switch (_selectedPlatformIndex) {
      case 0: // WhatsApp
        urlString = 'https://wa.me/$numberForWhatsApp';
        break;
      case 1: // WhatsApp Business
        urlString = 'https://api.whatsapp.com/send?phone=$numberForWhatsApp';
        break;
      case 2: // Telegram
        urlString = 'https://t.me/$numberForTelegram';
        break;
    }

    final Uri url = Uri.parse(urlString);

    try {
      // Android 11+ এ canLaunchUrl সমস্যা করতে পারে, তাই সরাসরি launchUrl ব্যবহার করা হলো
      final launched = await launchUrl(
        url,
        mode: LaunchMode.externalApplication, // অ্যাপটি ব্রাউজারের বদলে নির্দিষ্ট অ্যাপে ওপেন করার জন্য
      );
      
      if (!launched) {
        throw 'Could not launch $url';
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Could not open the app. Make sure it is installed.\nError: $e'),
            duration: const Duration(seconds: 4),
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Direct Chat'),
        centerTitle: true,
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
      ),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Text(
              'Message without saving the number',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 32),
            // Modern Country Code picker and Phone Number input
            IntlPhoneField(
              decoration: const InputDecoration(
                labelText: 'Phone Number',
                border: OutlineInputBorder(
                  borderSide: BorderSide(),
                ),
              ),
              initialCountryCode: 'BD', // Defaults to +880 (Bangladesh)
              onChanged: (phone) {
                setState(() {
                  _completePhoneNumber = phone.completeNumber;
                  _isValidNumber = phone.number.isNotEmpty;
                });
              },
            ),
            const SizedBox(height: 24),
            const Text(
              'Select Platform',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
            ),
            const SizedBox(height: 12),
            // Platform Selection buttons
            SegmentedButton<int>(
              segments: const [
                ButtonSegment<int>(
                  value: 0,
                  label: Text('WhatsApp'),
                  icon: Icon(Icons.chat),
                ),
                ButtonSegment<int>(
                  value: 1,
                  label: Text('Business'),
                  icon: Icon(Icons.store),
                ),
                ButtonSegment<int>(
                  value: 2,
                  label: Text('Telegram'),
                  icon: Icon(Icons.telegram),
                ),
              ],
              selected: {_selectedPlatformIndex},
              onSelectionChanged: (Set<int> newSelection) {
                setState(() {
                  _selectedPlatformIndex = newSelection.first;
                });
              },
            ),
            const Spacer(),
            // Open Chat primary button
            ElevatedButton.icon(
              onPressed: _openChat,
              icon: const Icon(Icons.send),
              label: const Text('Open Chat', style: TextStyle(fontSize: 18)),
              style: ElevatedButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 16),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                backgroundColor: Theme.of(context).colorScheme.primary,
                foregroundColor: Theme.of(context).colorScheme.onPrimary,
              ),
            ),
            const SizedBox(height: 24),
          ],
        ),
      ),
    );
  }
}