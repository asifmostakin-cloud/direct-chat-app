class MessagesData {
  // Supported Languages with Flags
  static const List<String> languages = [
    'English 🇺🇸',
    'বাংলা 🇧🇩',
    'العربية 🇸🇦',
    'हिन्दी 🇮🇳'
  ];

  // Message Categories
  static const List<String> categories = [
    'General',
    'Business & Sales',
    'Rider & Delivery',
    'Personal & Social',
    'Urgent & Official'
  ];

  // Data Dictionary: Language -> Category -> List of Messages
  static final Map<String, Map<String, List<String>>> _data = {
    'English 🇺🇸': {
      'General': [
        'Hi, I am interested.',
        'Can we talk now?',
        'Please send your location.',
        'Call me back.'
      ],
      'Business & Sales': [
        'What is the price?',
        'Is this available?',
        'Please send the catalog.',
        'Can I get a discount?'
      ],
      'Rider & Delivery': [
        'I am at your location.',
        'How long will it take?',
        'Please come to the gate.',
        'Delivery is confirmed.'
      ],
      'Personal & Social': [
        'How are you?',
        'Let\'s meet today.',
        'Happy Birthday!',
        'Talk to you later.'
      ],
      'Urgent & Official': [
        'Please check your email.',
        'This is urgent.',
        'Meeting starts in 5 mins.',
        'Please approve the document.'
      ],
    },
    'বাংলা 🇧🇩': {
      'General': [
        'হ্যালো, আমি আগ্রহী।',
        'আমরা কি এখন কথা বলতে পারি?',
        'অনুগ্রহ করে আপনার লোকেশন পাঠান।',
        'আমাকে কল ব্যাক করুন।'
      ],
      'Business & Sales': [
        'এটার দাম কত?',
        'এটা কি এভেইলেবল?',
        'দয়া করে ক্যাটালগ পাঠান।',
        'আমি কি ডিসকাউন্ট পেতে পারি?'
      ],
      'Rider & Delivery': [
        'আমি আপনার লোকেশনে আছি।',
        'কতক্ষণ সময় লাগবে?',
        'দয়া করে গেটের সামনে আসুন।',
        'ডেলিভারি কনফার্ম করা হয়েছে।'
      ],
      'Personal & Social': [
        'কেমন আছেন?',
        'আজকে দেখা করি চলেন।',
        'শুভ জন্মদিন!',
        'পরে কথা হবে।'
      ],
      'Urgent & Official': [
        'দয়া করে ইমেইল চেক করুন।',
        'এটি খুব জরুরি।',
        '৫ মিনিটের মধ্যে মিটিং শুরু হবে।',
        'ডকুমেন্টটি অ্যাপ্রুভ করুন।'
      ],
    },
    'العربية 🇸🇦': {
      'General': [
        'مرحباً، أنا مهتم.',
        'هل يمكننا التحدث الآن؟',
        'يرجى إرسال موقعك.',
        'اطلبني مرة أخرى.'
      ],
      'Business & Sales': [
        'كم السعر؟',
        'هل هذا متاح؟',
        'يرجى إرسال الكتالوج.',
        'هل يمكنني الحصول على خصم؟'
      ],
      'Rider & Delivery': [
        'أنا في موقعك.',
        'كم من الوقت سيستغرق؟',
        'يرجى القدوم إلى البوابة.',
        'تم تأكيد التوصيل.'
      ],
      'Personal & Social': [
        'كيف حالك؟',
        'دعنا نلتقي اليوم.',
        'عيد ميلاد سعيد!',
        'سأتحدث إليك لاحقاً.'
      ],
      'Urgent & Official': [
        'يرجى التحقق من بريدك الإلكتروني.',
        'هذا عاجل.',
        'يبدأ الاجتماع بعد 5 دقائق.',
        'يرجى الموافقة على المستند.'
      ],
    },
    'हिन्दी 🇮🇳': {
      'General': [
        'नमस्ते, मुझे दिलचस्पी है।',
        'क्या हम अभी बात कर सकते हैं?',
        'कृपया अपनी लोकेशन भेजें।',
        'मुझे वापस कॉल करें।'
      ],
      'Business & Sales': [
        'इसकी कीमत क्या है?',
        'क्या यह उपलब्ध है?',
        'कृपया कैटलॉग भेजें।',
        'क्या मुझे डिस्काउंट मिल सकता है?'
      ],
      'Rider & Delivery': [
        'मैं आपकी लोकेशन पर हूँ।',
        'कितना समय लगेगा?',
        'कृपया गेट पर आएं।',
        'डिलीवरी कन्फर्म हो गई है।'
      ],
      'Personal & Social': [
        'आप कैसे हैं?',
        'चलो आज मिलते हैं।',
        'जन्मदिन मुबारक हो!',
        'बाद में बात करते हैं।'
      ],
      'Urgent & Official': [
        'कृपया अपना ईमेल चेक करें।',
        'यह बहुत जरूरी है।',
        'मीटिंग 5 मिनट में शुरू होगी।',
        'कृपया दस्तावेज़ स्वीकृत करें।'
      ],
    },
  };

  // Helper method to get messages based on selected language and category
  static List<String> getMessages(String language, String category) {
    return _data[language]?[category] ?? [];
  }
}