import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl_phone_field/intl_phone_field.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:share_plus/share_plus.dart';
import 'package:android_intent_plus/android_intent.dart';
import 'package:in_app_review/in_app_review.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';

// -------------------------------------------------------------------------
// Global Action Handler for Interstitial Ads and In-App Review
// -------------------------------------------------------------------------
class AppActionHandler {
  static InterstitialAd? _interstitialAd;
  static bool _isInterstitialAdLoading = false;

  static void loadInterstitial() {
    if (_isInterstitialAdLoading || _interstitialAd != null) return;
    _isInterstitialAdLoading = true;
    InterstitialAd.load(
      adUnitId: 'ca-app-pub-3940256099942544/1033173712', // Test Interstitial Ad Unit ID
      request: const AdRequest(),
      adLoadCallback: InterstitialAdLoadCallback(
        onAdLoaded: (ad) {
          _interstitialAd = ad;
          _isInterstitialAdLoading = false;
        },
        onAdFailedToLoad: (error) {
          _isInterstitialAdLoading = false;
        },
      ),
    );
  }

  static Future<void> handleAction(BuildContext context, VoidCallback onContinue) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      
      bool hasReviewed = prefs.getBool('has_reviewed') ?? false;

      // In-App Review Logic (3rd action of the day)
      String today = DateTime.now().toIso8601String().substring(0, 10);
      String lastReviewDate = prefs.getString('last_review_date') ?? '';
      int dailyActionCount = prefs.getInt('daily_action_count_$today') ?? 0;
      
      dailyActionCount += 1;
      await prefs.setInt('daily_action_count_$today', dailyActionCount);

      // Interstitial Ad Logic (1st, 5th, 9th, 13th...)
      int totalActions = (prefs.getInt('total_action_count') ?? 0) + 1;
      await prefs.setInt('total_action_count', totalActions);

      bool showReview = false;
      if (!hasReviewed && dailyActionCount == 3 && lastReviewDate != today) {
        showReview = true;
        await prefs.setString('last_review_date', today);
      }

      void showInterstitialAndContinue() {
        // Show Interstitial Ad on 1st action, then every 4 actions
        if (totalActions == 1 || (totalActions - 1) % 4 == 0) {
          if (_interstitialAd != null) {
            _interstitialAd!.fullScreenContentCallback = FullScreenContentCallback(
              onAdDismissedFullScreenContent: (ad) {
                ad.dispose();
                _interstitialAd = null;
                loadInterstitial(); // Preload next ad
                onContinue(); // Redirect to App after ad is dismissed
              },
              onAdFailedToShowFullScreenContent: (ad, error) {
                ad.dispose();
                _interstitialAd = null;
                loadInterstitial();
                onContinue(); // Redirect if ad fails
              },
            );
            _interstitialAd!.show();
          } else {
            onContinue();
            loadInterstitial(); 
          }
        } else {
          onContinue();
        }
      }

      if (showReview) {
        // Show Custom Review Dialog
        showDialog(
          context: context,
          barrierDismissible: false,
          builder: (context) {
            return _buildReviewDialog(context, onContinue: showInterstitialAndContinue);
          }
        );
      } else {
        showInterstitialAndContinue();
      }
    } catch (e) {
      onContinue(); // Fallback to continue on any unexpected error
    }
  }

  static Widget _buildReviewDialog(BuildContext context, {VoidCallback? onContinue}) {
    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('Rate Us', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                IconButton(
                  icon: const Icon(Icons.close),
                  onPressed: () {
                    Navigator.pop(context);
                    if (onContinue != null) onContinue();
                  },
                ),
              ],
            ),
            const SizedBox(height: 10),
            const Icon(Icons.star, color: Colors.amber, size: 60),
            const SizedBox(height: 16),
            const Text(
              'Are you enjoying the app? Please take a moment to rate us on the Play Store. It helps us a lot!',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 16),
            ),
            const SizedBox(height: 24),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () async {
                  final prefs = await SharedPreferences.getInstance();
                  await prefs.setBool('has_reviewed', true);
                  
                  final InAppReview inAppReview = InAppReview.instance;
                  if (await inAppReview.isAvailable()) {
                    inAppReview.openStoreListing(appStoreId: 'com.directchat.clicktomessage.unsaved');
                  } else {
                    inAppReview.openStoreListing(appStoreId: 'com.directchat.clicktomessage.unsaved');
                  }
                  
                  if (context.mounted) {
                    Navigator.pop(context);
                  }
                  if (onContinue != null) onContinue();
                },
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  backgroundColor: const Color(0xFF075E54),
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                ),
                child: const Text('Rate Now', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
              ),
            )
          ],
        ),
      ),
    );
  }

  static Future<void> showReviewDialogFromSettings(BuildContext context) async {
    final prefs = await SharedPreferences.getInstance();
    bool hasReviewed = prefs.getBool('has_reviewed') ?? false;
    
    if (hasReviewed) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('You have already reviewed the app. Thank you!')));
      return;
    }
    
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) {
        return _buildReviewDialog(context, onContinue: null);
      }
    );
  }
}

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await MobileAds.instance.initialize();
  AppActionHandler.loadInterstitial(); // Preload the interstitial ad
  runApp(const DirectChatApp());
}

class DirectChatApp extends StatelessWidget {
  const DirectChatApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Direct Chat',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF075E54)),
        useMaterial3: true,
      ),
      home: const MainScreen(),
    );
  }
}

class MainScreen extends StatefulWidget {
  const MainScreen({super.key});

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  int _currentIndex = 0;
  
  final List<Widget> _screens = [
    const HomeScreen(),
    const RecentsScreen(),
  ];

  BannerAd? _bannerAd;
  bool _isBannerAdLoaded = false;

  @override
  void initState() {
    super.initState();
    _loadBannerAd();
  }

  void _loadBannerAd() {
    _bannerAd = BannerAd(
      adUnitId: 'ca-app-pub-3940256099942544/6300978111', // Test Banner Ad Unit ID
      size: AdSize.banner,
      request: const AdRequest(),
      listener: BannerAdListener(
        onAdLoaded: (_) {
          setState(() {
            _isBannerAdLoaded = true;
          });
        },
        onAdFailedToLoad: (ad, error) {
          ad.dispose();
        },
      ),
    )..load();
  }

  @override
  void dispose() {
    _bannerAd?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _screens[_currentIndex],
      bottomNavigationBar: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Banner Ad displayed persistently above the BottomNavigationBar
          if (_isBannerAdLoaded && _bannerAd != null)
            Container(
              alignment: Alignment.center,
              width: _bannerAd!.size.width.toDouble(),
              height: _bannerAd!.size.height.toDouble(),
              child: AdWidget(ad: _bannerAd!),
            ),
          BottomNavigationBar(
            currentIndex: _currentIndex,
            onTap: (index) {
              setState(() {
                _currentIndex = index;
              });
            },
            items: const [
              BottomNavigationBarItem(
                icon: Icon(Icons.chat),
                label: 'Click to Chat',
              ),
              BottomNavigationBarItem(
                icon: Icon(Icons.history),
                label: 'Recents',
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final TextEditingController _phoneController = TextEditingController();
  final TextEditingController _messageController = TextEditingController();
  
  String _countryCode = '+880';
  int _selectedPlatformIndex = 0; // 0 = WhatsApp, 1 = Telegram
  
  String _selectedLanguage = 'English (🇺🇸)';
  String _selectedCategory = 'General';

  @override
  void dispose() {
    _phoneController.dispose();
    _messageController.dispose();
    super.dispose();
  }

  Future<void> _pasteFromClipboard() async {
    ClipboardData? data = await Clipboard.getData('text/plain');
    if (data != null && data.text != null) {
      String cleanText = data.text!.replaceAll(RegExp(r'[^\d+]'), '');
      if (cleanText.isNotEmpty) {
        setState(() {
          _phoneController.text = cleanText;
        });
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Number pasted!')),
        );
      }
    }
  }

  Future<void> _saveToHistory(String fullNumber, String localNumber, int platform) async {
    final prefs = await SharedPreferences.getInstance();
    List<String> history = prefs.getStringList('chat_history') ?? [];
    
    final newItem = jsonEncode({
      'number': fullNumber,
      'localNumber': localNumber,
      'platform': platform,
      'nickname': '',
      'timestamp': DateTime.now().toIso8601String(),
    });
    
    history.removeWhere((item) {
      final decoded = jsonDecode(item);
      return decoded['number'] == fullNumber && decoded['platform'] == platform;
    });
    
    history.insert(0, newItem);
    if (history.length > 100) history = history.sublist(0, 100);
    await prefs.setStringList('chat_history', history);
  }

  Future<void> _openWhatsAppAction({required String completeNumber, required String localNumber, required String text, required bool isBusiness}) async {
    AppActionHandler.handleAction(context, () {
      _executeOpenWhatsApp(completeNumber: completeNumber, localNumber: localNumber, text: text, isBusiness: isBusiness);
    });
  }

  Future<void> _executeOpenWhatsApp({required String completeNumber, required String localNumber, required String text, required bool isBusiness}) async {
    final String packageName = isBusiness ? 'com.whatsapp.w4b' : 'com.whatsapp';
    final String cleanPhone = completeNumber.replaceAll(RegExp(r'\D'), '');
    
    final String url = text.isNotEmpty 
        ? 'https://api.whatsapp.com/send?phone=$cleanPhone&text=${Uri.encodeComponent(text)}'
        : 'https://api.whatsapp.com/send?phone=$cleanPhone';
    
    try {
      final AndroidIntent intent = AndroidIntent(
        action: 'action_view',
        data: url,
        package: packageName,
      );
      await intent.launch();
      await _saveToHistory('+$cleanPhone', localNumber, isBusiness ? 1 : 0);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Could not open the app. Make sure it is installed.\nError: $e'),
            duration: const Duration(seconds: 4),
          ),
        );
      }
    }
  }

  void _showWhatsAppBottomSheet(String completeNumber, String localNumber) {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (BuildContext context) {
        return Padding(
          padding: const EdgeInsets.symmetric(vertical: 24.0, horizontal: 16.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text(
                'Open With',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF075E54),
                ),
              ),
              const SizedBox(height: 24),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  _buildBottomSheetOption(
                    title: 'WhatsApp',
                    icon: FontAwesomeIcons.whatsapp,
                    color: Colors.green,
                    onTap: () {
                      Navigator.pop(context);
                      _openWhatsAppAction(
                        completeNumber: completeNumber,
                        localNumber: localNumber,
                        text: _messageController.text,
                        isBusiness: false,
                      );
                    },
                  ),
                  _buildBottomSheetOption(
                    title: 'WA Business',
                    icon: FontAwesomeIcons.whatsapp,
                    isBusinessIcon: true,
                    color: const Color(0xFF075E54),
                    onTap: () {
                      Navigator.pop(context);
                      _openWhatsAppAction(
                        completeNumber: completeNumber,
                        localNumber: localNumber,
                        text: _messageController.text,
                        isBusiness: true,
                      );
                    },
                  ),
                ],
              ),
              const SizedBox(height: 16),
            ],
          ),
        );
      },
    );
  }

  Widget _buildBottomSheetOption({
    required String title, 
    required IconData icon, 
    bool isBusinessIcon = false,
    required Color color, 
    required VoidCallback onTap
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          CircleAvatar(
            radius: 28,
            backgroundColor: color.withOpacity(0.15),
            child: isBusinessIcon 
              ? Stack(
                  alignment: Alignment.center,
                  children: [
                    FaIcon(icon, color: color, size: 32),
                    // WA Business 'B' overlay representation
                    Container(
                      width: 15,
                      height: 15,
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                        color: Color.alphaBlend(color.withOpacity(0.15), Colors.white), 
                        shape: BoxShape.circle,
                      ),
                    ),
                    Text(
                      'B', 
                      style: TextStyle(
                        color: color, 
                        fontSize: 14, 
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                )
              : FaIcon(icon, color: color, size: 32),
          ),
          const SizedBox(height: 8),
          Text(title, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w500)),
        ],
      ),
    );
  }

  Future<void> _openTelegramAction({required String completeNumber, required String localNumber}) async {
    AppActionHandler.handleAction(context, () {
      _executeOpenTelegram(completeNumber: completeNumber, localNumber: localNumber);
    });
  }

  Future<void> _executeOpenTelegram({required String completeNumber, required String localNumber}) async {
    final message = Uri.encodeComponent(_messageController.text);
    String urlString = 'https://t.me/+$completeNumber${message.isNotEmpty ? "?text=$message" : ""}';
    final Uri url = Uri.parse(urlString);

    try {
      final launched = await launchUrl(url, mode: LaunchMode.externalApplication);
      if (launched) {
        await _saveToHistory('+$completeNumber', localNumber, 2); // 2 is Telegram
      } else {
        throw 'Could not launch $url';
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Could not open the app. Make sure it is installed.\nError: $e'),
            duration: const Duration(seconds: 4),
          ),
        );
      }
    }
  }

  Future<void> _openChat({required bool isCall}) async {
    String typedNumberRaw = _phoneController.text.trim();
    
    if (typedNumberRaw.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please enter a phone number')),
      );
      return;
    }

    String localNumber = typedNumberRaw.replaceAll(RegExp(r'[^\d]'), '');
    String typedNumber = localNumber;

    if (typedNumber.startsWith('0')) {
      typedNumber = typedNumber.substring(1);
    }
    
    String countryCodeDigits = _countryCode.replaceAll(RegExp(r'[^\d]'), '');
    String completeNumber = '$countryCodeDigits$typedNumber';
    
    if (isCall) {
      AppActionHandler.handleAction(context, () async {
        final Uri url = Uri.parse('tel:+$completeNumber');
        try {
          await launchUrl(url);
        } catch (e) {
          if (mounted) {
            ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Could not open dialer')));
          }
        }
      });
      return;
    }

    if (_selectedPlatformIndex == 0) {
      _showWhatsAppBottomSheet(completeNumber, localNumber);
    } else {
      _openTelegramAction(completeNumber: completeNumber, localNumber: localNumber);
    }
  }

  Widget _buildPlatformOption(int index, String title, IconData icon) {
    final isSelected = _selectedPlatformIndex == index;
    return Expanded(
      child: GestureDetector(
        onTap: () {
          setState(() {
            _selectedPlatformIndex = index;
          });
        },
        child: Container(
          margin: const EdgeInsets.symmetric(horizontal: 4),
          padding: const EdgeInsets.symmetric(vertical: 12),
          decoration: BoxDecoration(
            color: isSelected ? Theme.of(context).colorScheme.primaryContainer : Colors.transparent,
            border: Border.all(
              color: isSelected ? Theme.of(context).colorScheme.primary : Colors.grey.shade400,
              width: 1.5,
            ),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              FaIcon(
                icon,
                color: isSelected ? Theme.of(context).colorScheme.primary : Colors.grey.shade600,
                size: 24,
              ),
              const SizedBox(height: 8),
              Text(
                title,
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                  color: isSelected ? Theme.of(context).colorScheme.primary : Colors.grey.shade700,
                ),
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    List<String> currentQuickNotes = QuickMessagesData.messages[_selectedLanguage]![_selectedCategory] ?? [];

    return Scaffold(
      appBar: AppBar(
        title: const Text('Direct Chat'),
        backgroundColor: Theme.of(context).colorScheme.primary,
        foregroundColor: Theme.of(context).colorScheme.onPrimary,
        elevation: 0,
        actions: [
          PopupMenuButton<String>(
            icon: const Icon(Icons.settings),
            onSelected: (value) async {
              if (value == 'rate') {
                AppActionHandler.showReviewDialogFromSettings(context);
              } else if (value == 'share') {
                Share.share('https://play.google.com/store/apps/details?id=com.directchat.clicktomessage.unsaved');
              } else if (value == 'privacy') {
                final url = Uri.parse('https://sites.google.com/view/directchatprivacypolicy/home');
                if (await canLaunchUrl(url)) {
                  await launchUrl(url, mode: LaunchMode.externalApplication);
                } else {
                  if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Could not open Privacy Policy')));
                }
              } else if (value == 'about') {
                showAboutDialog(
                  context: context,
                  applicationName: 'Direct Chat',
                  applicationVersion: '1.0.0',
                  applicationLegalese: '© 2026 Direct Chat',
                  children: [
                    const Text('Send direct messages via WhatsApp, WhatsApp Business, and Telegram without saving contacts. Features quick templates in multiple languages.'),
                  ],
                );
              }
            },
            itemBuilder: (BuildContext context) => [
              const PopupMenuItem<String>(
                value: 'rate',
                child: Row(
                  children: [
                    Icon(Icons.star_rate, size: 20, color: Colors.black87),
                    SizedBox(width: 12),
                    Text('Rate Us'),
                  ],
                ),
              ),
              const PopupMenuItem<String>(
                value: 'share',
                child: Row(
                  children: [
                    Icon(Icons.share, size: 20, color: Colors.black87),
                    SizedBox(width: 12),
                    Text('Share App'),
                  ],
                ),
              ),
              const PopupMenuItem<String>(
                value: 'privacy',
                child: Row(
                  children: [
                    Icon(Icons.privacy_tip_outlined, size: 20, color: Colors.black87),
                    SizedBox(width: 12),
                    Text('Privacy Policy'),
                  ],
                ),
              ),
              const PopupMenuItem<String>(
                value: 'about',
                child: Row(
                  children: [
                    Icon(Icons.info_outline, size: 20, color: Colors.black87),
                    SizedBox(width: 12),
                    Text('About Us'),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Text(
              'Message without saving the number',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 24),
            IntlPhoneField(
              controller: _phoneController,
              decoration: InputDecoration(
                labelText: 'Phone Number',
                border: const OutlineInputBorder(),
                prefixIcon: const Icon(Icons.phone),
                suffixIcon: IconButton(
                  icon: const Icon(Icons.paste),
                  onPressed: _pasteFromClipboard,
                  tooltip: 'Paste Number',
                ),
              ),
              initialCountryCode: 'BD', 
              disableLengthCheck: true, 
              onCountryChanged: (country) {
                _countryCode = '+${country.dialCode}';
              },
            ),
            const SizedBox(height: 16),
            const Text(
              'Select Platform',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                _buildPlatformOption(0, 'WhatsApp', FontAwesomeIcons.whatsapp),
                _buildPlatformOption(1, 'Telegram', FontAwesomeIcons.telegram),
              ],
            ),
            const SizedBox(height: 24),
            
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  'Quick Message',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                ),
                DropdownButtonHideUnderline(
                  child: DropdownButton<String>(
                    value: _selectedLanguage,
                    icon: const Icon(Icons.language, size: 18),
                    style: TextStyle(color: Theme.of(context).colorScheme.primary, fontWeight: FontWeight.w600),
                    items: QuickMessagesData.languages.map((lang) {
                      return DropdownMenuItem(value: lang, child: Text(lang));
                    }).toList(),
                    onChanged: (val) {
                      if (val != null) setState(() => _selectedLanguage = val);
                    },
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),

            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: QuickMessagesData.categories.map((cat) {
                  final isSelected = _selectedCategory == cat;
                  return Padding(
                    padding: const EdgeInsets.only(right: 8.0),
                    child: ChoiceChip(
                      label: Text(cat),
                      selected: isSelected,
                      selectedColor: Theme.of(context).colorScheme.primaryContainer,
                      onSelected: (selected) {
                        if(selected) setState(() => _selectedCategory = cat);
                      },
                    ),
                  );
                }).toList(),
              ),
            ),
            const SizedBox(height: 12),

            TextField(
              controller: _messageController,
              decoration: const InputDecoration(
                hintText: 'Type your message here...',
                border: OutlineInputBorder(),
              ),
              maxLines: 2,
            ),
            const SizedBox(height: 12),

            Wrap(
              spacing: 8,
              children: currentQuickNotes.map((note) => ActionChip(
                label: Text(note, style: const TextStyle(fontSize: 12)),
                onPressed: () {
                  setState(() {
                    _messageController.text = note;
                  });
                },
              )).toList(),
            ),
            const SizedBox(height: 32),
            Row(
              children: [
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: () => _openChat(isCall: true),
                    icon: const Icon(Icons.call),
                    label: const Text('Call', style: TextStyle(fontSize: 16)),
                    style: ElevatedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      backgroundColor: Colors.grey.shade200,
                      foregroundColor: Colors.black87,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    ),
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  flex: 2,
                  child: ElevatedButton.icon(
                    onPressed: () => _openChat(isCall: false),
                    icon: const Icon(Icons.send),
                    label: const Text('Message', style: TextStyle(fontSize: 16)),
                    style: ElevatedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      backgroundColor: Theme.of(context).colorScheme.primary,
                      foregroundColor: Theme.of(context).colorScheme.onPrimary,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

// -------------------------------------------------------------------------
// Custom Stateful Dialog for Nickname to prevent keyboard dismissal
// -------------------------------------------------------------------------
class NicknameDialog extends StatefulWidget {
  final String initialName;
  
  const NicknameDialog({super.key, required this.initialName});

  @override
  State<NicknameDialog> createState() => _NicknameDialogState();
}

class _NicknameDialogState extends State<NicknameDialog> {
  late TextEditingController _controller;
  late FocusNode _focusNode;

  @override
  void initState() {
    super.initState();
    _controller = TextEditingController(text: widget.initialName);
    _focusNode = FocusNode();
    
    // Auto focus on the text field when dialog opens
    WidgetsBinding.instance.addPostFrameCallback((_) {
      FocusScope.of(context).requestFocus(_focusNode);
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    _focusNode.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Assign Nickname'),
      content: TextField(
        controller: _controller,
        focusNode: _focusNode,
        autofocus: true,
        textCapitalization: TextCapitalization.words,
        decoration: const InputDecoration(hintText: 'Enter name (e.g. Asif)'),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context), 
          child: const Text('Cancel')
        ),
        TextButton(
          onPressed: () {
            Navigator.pop(context, _controller.text.trim());
          }, 
          child: const Text('Save')
        ),
      ],
    );
  }
}

class RecentsScreen extends StatefulWidget {
  const RecentsScreen({super.key});

  @override
  State<RecentsScreen> createState() => _RecentsScreenState();
}

class _RecentsScreenState extends State<RecentsScreen> {
  List<Map<String, dynamic>> _history = [];

  @override
  void initState() {
    super.initState();
    _loadHistory();
  }

  Future<void> _loadHistory() async {
    final prefs = await SharedPreferences.getInstance();
    final List<String> historyStrings = prefs.getStringList('chat_history') ?? [];
    
    setState(() {
      _history = historyStrings.map((str) => jsonDecode(str) as Map<String, dynamic>).toList();
    });
  }

  Future<void> _saveFullHistory() async {
    final prefs = await SharedPreferences.getInstance();
    List<String> historyStrings = _history.map((item) => jsonEncode(item)).toList();
    await prefs.setStringList('chat_history', historyStrings);
  }

  Future<void> _clearHistory() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('chat_history');
    setState(() {
      _history = [];
    });
  }
  
  IconData _getPlatformIcon(int platform) {
    switch (platform) {
      case 0: return FontAwesomeIcons.whatsapp;
      case 1: return FontAwesomeIcons.whatsapp;
      case 2: return FontAwesomeIcons.telegram;
      default: return Icons.chat;
    }
  }

  String _getPlatformName(int platform) {
    switch (platform) {
      case 0: return 'WhatsApp';
      case 1: return 'WA Business';
      case 2: return 'Telegram';
      default: return 'Unknown';
    }
  }

  void _actionCallOrMessage(Map<String, dynamic> item, bool isCall) async {
    AppActionHandler.handleAction(context, () {
      _executeActionCallOrMessage(item, isCall);
    });
  }

  void _executeActionCallOrMessage(Map<String, dynamic> item, bool isCall) async {
    String fullNumber = item['number'] ?? '';
    int platform = item['platform'] ?? 0;
    String cleanNumber = fullNumber.replaceAll(RegExp(r'[^\d+]'), '');
    
    if (isCall) {
      try {
        await launchUrl(Uri.parse('tel:$cleanNumber'));
      } catch (e) {
        // ignore
      }
      return;
    }

    if (platform == 0 || platform == 1) { // 0 = WA, 1 = WA Business
      final bool isBusiness = platform == 1;
      final String packageName = isBusiness ? 'com.whatsapp.w4b' : 'com.whatsapp';
      final String cleanPhone = cleanNumber.replaceAll(RegExp(r'\D'), '');
      final String url = 'https://api.whatsapp.com/send?phone=$cleanPhone';
      
      try {
        final AndroidIntent intent = AndroidIntent(
          action: 'action_view',
          data: url,
          package: packageName,
        );
        await intent.launch();
      } catch (e) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Could not open chat')));
        }
      }
    } else if (platform == 2) { // Telegram
      String urlString = 'https://t.me/$cleanNumber';
      try {
        await launchUrl(Uri.parse(urlString), mode: LaunchMode.externalApplication);
      } catch (e) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Could not open chat')));
        }
      }
    }
  }

  void _copyNumber(Map<String, dynamic> item) {
    String fullNumber = item['number'] ?? '';
    String localNumber = item['localNumber'] ?? '';
    
    // Copy the exact local number entered. If it's old history lacking localNumber, fallback to fullNumber
    String copyText = localNumber.isNotEmpty ? localNumber : fullNumber;
    
    Clipboard.setData(ClipboardData(text: copyText));
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Copied to clipboard')),
    );
  }

  void _shareNumber(String number) {
    Share.share('Contact Number: $number');
  }

  Future<void> _editNickname(int index) async {
    // এখানে ডায়ালগটিকে একটি আলাদা স্টেটফুল উইজেট (NicknameDialog) দিয়ে রিপ্লেস করা হয়েছে
    final String? newName = await showDialog<String>(
      context: context,
      builder: (context) => NicknameDialog(
        initialName: _history[index]['nickname'] ?? '',
      ),
    );

    // যদি ইউজার Save বাটনে ক্লিক করে কোনো নাম রিটার্ন করে
    if (newName != null) {
      setState(() {
        _history[index]['nickname'] = newName;
      });
      await _saveFullHistory();
    }
  }

  Future<void> _deleteItem(int index) async {
    setState(() {
      _history.removeAt(index);
    });
    await _saveFullHistory();
  }

  Widget _buildActionIcon(IconData icon, String tooltip, VoidCallback onTap) {
    return IconButton(
      icon: Icon(icon),
      tooltip: tooltip,
      onPressed: onTap,
      color: Theme.of(context).colorScheme.primary,
      iconSize: 22,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Recent History'),
        backgroundColor: Theme.of(context).colorScheme.primary,
        foregroundColor: Theme.of(context).colorScheme.onPrimary,
        actions: [
          IconButton(
            icon: const Icon(Icons.delete_outline),
            onPressed: () {
              showDialog(
                context: context,
                builder: (context) => AlertDialog(
                  title: const Text('Clear History'),
                  content: const Text('Are you sure you want to clear all history?'),
                  actions: [
                    TextButton(
                      onPressed: () => Navigator.pop(context),
                      child: const Text('Cancel'),
                    ),
                    TextButton(
                      onPressed: () {
                        _clearHistory();
                        Navigator.pop(context);
                      },
                      child: const Text('Clear'),
                    ),
                  ],
                ),
              );
            },
          ),
        ],
      ),
      body: _history.isEmpty
          ? const Center(child: Text('No recent chats found.'))
          : ListView.builder(
              padding: const EdgeInsets.all(12),
              itemCount: _history.length,
              itemBuilder: (context, index) {
                final item = _history[index];
                final platform = item['platform'] as int;
                final number = item['number'] as String;
                final nickname = item['nickname'] as String? ?? '';

                return Card(
                  elevation: 2,
                  margin: const EdgeInsets.only(bottom: 12),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            CircleAvatar(
                              backgroundColor: Theme.of(context).colorScheme.primaryContainer,
                              child: FaIcon(
                                _getPlatformIcon(platform),
                                color: Theme.of(context).colorScheme.primary,
                                size: 20,
                              ),
                            ),
                            const SizedBox(width: 16),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    nickname.isNotEmpty ? nickname : number,
                                    style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                                  ),
                                  if (nickname.isNotEmpty)
                                    Text(
                                      number,
                                      style: TextStyle(color: Colors.grey.shade700, fontSize: 14),
                                    ),
                                  const SizedBox(height: 4),
                                  Text(
                                    _getPlatformName(platform),
                                    style: TextStyle(color: Colors.grey.shade500, fontSize: 12),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                        const Padding(
                          padding: EdgeInsets.symmetric(vertical: 8.0),
                          child: Divider(),
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          children: [
                            _buildActionIcon(Icons.call, 'Call', () => _actionCallOrMessage(item, true)),
                            _buildActionIcon(Icons.message, 'Message', () => _actionCallOrMessage(item, false)),
                            _buildActionIcon(Icons.copy, 'Copy', () => _copyNumber(item)),
                            _buildActionIcon(Icons.share, 'Share', () => _shareNumber(number)),
                            _buildActionIcon(Icons.edit, 'Edit Nickname', () => _editNickname(index)),
                            _buildActionIcon(Icons.delete, 'Delete', () => _deleteItem(index)),
                          ],
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
    );
  }
}

class QuickMessagesData {
  static const List<String> languages = [
    'English (🇺🇸)', 
    'Bengali (🇧🇩)', 
    'Arabic (🇸🇦)', 
    'Hindi (🇮🇳)'
  ];
  
  static const List<String> categories = [
    'General', 
    'Business & Sales', 
    'Rider & Delivery', 
    'Personal & Social', 
    'Urgent & Official'
  ];

  static const Map<String, Map<String, List<String>>> messages = {
    'English (🇺🇸)': {
      'General': [
        'Hi, I am interested.', 
        'Can we talk now?', 
        'Please send your location.', 
        'Call me back.', 
        'How are you?'
      ],
      'Business & Sales': [
        'What is the price?', 
        'Is this item available?', 
        'Send me your catalog.', 
        'Can I get a discount?', 
        'Payment done.'
      ],
      'Rider & Delivery': [
        'I am at the location.', 
        'Please come downstairs.', 
        'How long will it take?', 
        'Call me when you arrive.', 
        'I cannot find the address.'
      ],
      'Personal & Social': [
        'Happy Birthday!', 
        'Congratulations!', 
        'Let\'s meet up.', 
        'Check this out.', 
        'Are you free today?'
      ],
      'Urgent & Official': [
        'Please reply urgently.', 
        'Send the report.', 
        'Join the meeting.', 
        'I am on my way.', 
        'Call me ASAP.'
      ],
    },
    'Bengali (🇧🇩)': {
      'General': [
        'হাই, আমি আগ্রহী।', 
        'আমরা কি এখন কথা বলতে পারি?', 
        'অনুগ্রহ করে আপনার লোকেশন দিন।', 
        'আমাকে কল ব্যাক করুন।', 
        'আপনি কেমন আছেন?'
      ],
      'Business & Sales': [
        'এটার দাম কত?', 
        'এই আইটেমটি কি এভেইলেবল?', 
        'আপনার ক্যাটালগ পাঠান।', 
        'আমি কি ডিসকাউন্ট পেতে পারি?', 
        'পেমেন্ট সম্পন্ন হয়েছে।'
      ],
      'Rider & Delivery': [
        'আমি লোকেশনে আছি।', 
        'দয়া করে নিচে আসুন।', 
        'কতক্ষণ লাগবে?', 
        'পৌঁছে আমাকে কল করুন।', 
        'আমি ঠিকানাটি খুঁজে পাচ্ছি না।'
      ],
      'Personal & Social': [
        'শুভ জন্মদিন!', 
        'অভিনন্দন!', 
        'চলো দেখা করি।', 
        'এটা দেখুন।', 
        'আজকে কি তুমি ফ্রি আছো?'
      ],
      'Urgent & Official': [
        'দয়া করে দ্রুত উত্তর দিন।', 
        'রিপোর্টটি পাঠান।', 
        'মিটিংয়ে জয়েন করুন।', 
        'আমি রাস্তায় আছি।', 
        'যত দ্রুত সম্ভব কল করুন।'
      ],
    },
    'Arabic (🇸🇦)': {
      'General': [
        'مرحباً، أنا مهتم.', 
        'هل يمكننا التحدث الآن؟', 
        'يرجى إرسال موقعك.', 
        'اتصل بي لاحقاً.', 
        'كيف حالك؟'
      ],
      'Business & Sales': [
        'كم السعر؟', 
        'هل هذا العنصر متوفر؟', 
        'أرسل لي الكتالوج الخاص بك.', 
        'هل يمكنني الحصول على خصم؟', 
        'تم الدفع.'
      ],
      'Rider & Delivery': [
        'أنا في الموقع.', 
        'يرجى النزول.', 
        'كم من الوقت سيستغرق؟', 
        'اتصل بي عندما تصل.', 
        'لا أستطيع العثور على العنوان.'
      ],
      'Personal & Social': [
        'عيد ميلاد سعيد!', 
        'تهانينا!', 
        'دعنا نلتقي.', 
        'تحقق من هذا.', 
        'هل أنت متفرغ اليوم؟'
      ],
      'Urgent & Official': [
        'يرجى الرد بشكل عاجل.', 
        'أرسل التقرير.', 
        'انضم إلى الاجتماع.', 
        'أنا في طريقي.', 
        'اتصل بي في أقرب وقت.'
      ],
    },
    'Hindi (🇮🇳)': {
      'General': [
        'नमस्ते, मुझे दिलचस्पी है।', 
        'क्या हम अभी बात कर सकते हैं?', 
        'कृपया अपनी लोकेशन भेजें।', 
        'मुझे वापस कॉल करें।', 
        'आप कैसे हैं?'
      ],
      'Business & Sales': [
        'इसकी कीमत क्या है?', 
        'क्या यह आइटम उपलब्ध है?', 
        'मुझे अपना कैटलॉग भेजें।', 
        'क्या मुझे डिस्काउंट मिल सकता है?', 
        'भुगतान हो गया।'
      ],
      'Rider & Delivery': [
        'मैं लोकेशन पर हूँ।', 
        'कृपया नीचे आएं।', 
        'कितना समय लगेगा?', 
        'पहुंचने पर मुझे कॉल करें।', 
        'मुझे पता नहीं मिल रहा है।'
      ],
      'Personal & Social': [
        'जन्मदिन की शुभकामनाएं!', 
        'बधाई हो!', 
        'चलो मिलते हैं।', 
        'इसे देखें।', 
        'क्या आप आज फ्री हैं?'
      ],
      'Urgent & Official': [
        'कृपया तुरंत उत्तर दें।', 
        'रिपोर्ट भेजें।', 
        'मीटिंग में शामिल हों।', 
        'मैं रास्ते में हूँ।', 
        'मुझे जल्द से जल्द कॉल करें।'
      ],
    },
  };
}